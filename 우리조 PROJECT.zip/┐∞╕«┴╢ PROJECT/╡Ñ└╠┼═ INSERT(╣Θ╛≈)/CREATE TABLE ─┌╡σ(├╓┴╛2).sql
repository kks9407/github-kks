CREATE TABLE ADDRESS_TBL --�ּ����̺� (�������̺�)
(
    A_ID            CHAR(5)         NOT NULL        PRIMARY KEY,
    A_VAL           VARCHAR2(20)    NOT NULL,
    A_LVL           NUMBER(5)       NOT NULL,
    A_PARENT_ID     CHAR(5)         NULL,
    GROUP_ID        CHAR(5)         NOT NULL
);

CREATE TABLE GROUP_TBL( --�׷����̺� (�׷��ڵ�)
    G_ID            CHAR(5)         NOT NULL        PRIMARY KEY,
    GROUP_NAME      VARCHAR2(20)    NOT NULL
);

CREATE TABLE TIME_TBL --�ð�ǥ ���̺�
(
    T_ID            CHAR(5)         NOT NULL        PRIMARY KEY,
    T_START       VARCHAR2(10)	NULL,	
    T_END	        VARCHAR2(10)	NULL,
    VEHICLE_ID	    CHAR(7)	        NOT NULL

);

CREATE TABLE VISIT_TBL --�湮��� ���̺�
(
    VISIT_ID            CHAR(7)         NOT NULL        PRIMARY KEY,
    P_ID                CHAR(5)         NOT NULL,
    B_ID                CHAR(5)         NOT NULL,
    CHECK_IN            DATE            NOT NULL,
    CHECK_OUT           DATE            NOT NULL,
    V_TEM               NUMBER(3,1)     NOT NULL
);

CREATE TABLE MSG_TBL    --�޽��� ���̺�
(
    MSG_ID          CHAR(5)         NOT NULL        PRIMARY KEY,
    MSG_VALUE       VARCHAR2(100)   NOT NULL
);

CREATE TABLE CHECK_UP_TBL   --�˻� ���̺�
(
    CHK_ID          CHAR(7)         NOT NULL        PRIMARY KEY,
    SM_ID           CHAR(7)         NOT NULL,
    C_YN            CHAR(1)         NOT NULL, -- 0: ����, 1:�缺
    CHK_DATE        DATE            NOT NULL
);

CREATE TABLE CONTAGION_TBL      --Ȯ�� ���̺�
(
    CON_ID          CHAR(7)         NOT NULL        PRIMARY KEY,
    CHK_ID          CHAR(7)         NOT NULL,
    CON_DATE        DATE            NOT NULL
);

CREATE TABLE PEOPLE_TBL     --��� ���̺�
(
    P_ID        CHAR(5)         NOT NULL  PRIMARY KEY,
    P_NAME      VARCHAR2(30)    NOT NULL,
    P_GENDER    CHAR(1)         NOT NULL,
    P_TEL       VARCHAR2(20)    NOT NULL,
    P_BIRTH     DATE            NOT NULL,
    P_ADD       CHAR(5)         NOT NULL
);

CREATE TABLE BUILDING_TBL       --�ǹ� ���̺�
(
    B_ID        CHAR(5)         NOT NULL  PRIMARY KEY,
    B_NAME      VARCHAR2(30)    NOT NULL,
    B_TEL       VARCHAR2(20)    NOT NULL,
    B_ADD       CHAR(5)         
);

CREATE TABLE VEHICLE_TBL --(GROUP_CODE) ����
(
    VEHICLE_ID        CHAR(7)         NOT NULL  PRIMARY KEY,
    VEHICLE_NAME      VARCHAR2(30)    NOT NULL      
);

CREATE TABLE GET_IN_TBL --�������̺�
(
    GET_IN_ID        CHAR(7)    NOT NULL  PRIMARY KEY,
    P_ID             CHAR(5)    NOT NULL,
    T_ID             CHAR(5)    NOT NULL,
    CHECK_IN          DATE       NOT NULL,
    CHECK_OUT         DATE       NOT NULL
);

CREATE TABLE SEND_MSG_TBL       --���ڹ߼����̺�
(
    SM_ID        CHAR(7)    NOT NULL  PRIMARY KEY,
    VISIT_ID     CHAR(7)    NULL,
    MSG_ID       CHAR(5)    NOT NULL,
    SM_DATE      DATE       NOT NULL,
    GET_IN_ID    CHAR(7)    NULL
);