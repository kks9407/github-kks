

SELECT NVL(D1,D2-1),NVL(CNT1,0),D2,CNT2 ,CNT2 - NVL(CNT1,0) AS ������
FROM (
        SELECT CON_DATE AS D1 ,COUNT(*) AS CNT1
        FROM CONTAGION_TBL 
        GROUP BY CON_DATE
     ) A, 
     (
        SELECT CON_DATE AS D2 ,COUNT(*) AS CNT2
        FROM CONTAGION_TBL
        GROUP BY CON_DATE
     ) B
WHERE TO_CHAR(D1(+),'YYYYMMDD') = TO_CHAR((D2-1),'YYYYMMDD')
;

SELECT T5.*
FROM CONTAGION_TBL T1, CHECK_UP_TBL T2, SEND_MSG_TBL T3,GET_IN_TBL T4,PEOPLE_TBL T5
WHERE T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID IS NULL AND T3.GET_IN_ID = T4.GET_IN_ID AND T4.P_ID = T5.P_ID 

UNION

SELECT T5.*
FROM CONTAGION_TBL T1, CHECK_UP_TBL T2, SEND_MSG_TBL T3,VISIT_TBL T4,PEOPLE_TBL T5
WHERE T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.GET_IN_ID IS NULL AND T3.VISIT_ID = T4.VISIT_ID AND T4.P_ID = T5.P_ID 
;

---------------------------------------------------------------
SELECT DECODE(P_GENDER,'F','����','����') AS GENDER ,COUNT(*)
FROM (
        SELECT T5.*
        FROM CONTAGION_TBL T1, CHECK_UP_TBL T2, SEND_MSG_TBL T3,GET_IN_TBL T4,PEOPLE_TBL T5
        WHERE T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID IS NULL AND T3.GET_IN_ID = T4.GET_IN_ID AND T4.P_ID = T5.P_ID 
        
        UNION
        
        SELECT T5.*
        FROM CONTAGION_TBL T1, CHECK_UP_TBL T2, SEND_MSG_TBL T3,VISIT_TBL T4,PEOPLE_TBL T5
        WHERE T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.GET_IN_ID IS NULL AND T3.VISIT_ID = T4.VISIT_ID AND T4.P_ID = T5.P_ID 
     )
GROUP BY P_GENDER;


SELECT P_ID
FROM CONTAGION_TBL T1, CHECK_UP_TBL T2, SEND_MSG_TBL T3,VISIT_TBL T4
WHERE T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.GET_IN_ID IS NULL AND T3.VISIT_ID = T4.VISIT_ID 

UNION

SELECT P_ID
FROM CONTAGION_TBL T1, CHECK_UP_TBL T2, SEND_MSG_TBL T3,GET_IN_TBL T4
WHERE T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID IS NULL AND T3.GET_IN_ID = T4.GET_IN_ID 
;

    
    --DELETE FROM SEND_MSG_TBL;
    SELECT * FROM TEST;
    SELECT * FROM SEND_MSG_TBL;
    --COMMIT;
    SELECT * FROM VISIT_TBL;
    SELECT * FROM TEST;
    SELECT * FROM SEND_MSG_TBL;
    SELECT * FROM CHECK_UP_TBL;
    SELECT * FROM CONTAGION_TBL;
    --DELETE FROM VISIT_TBL;
    
    INSERT INTO SEND_MSG_TBL
    SELECT 
    'SM' || TO_CHAR((SELECT TO_NUMBER(SUBSTR(NVL(MAX(SM_ID), 'SM00000'), 3)) FROM SEND_MSG_TBL) + ROW_NUMBER() OVER(ORDER BY VISIT_ID), 'FM00000')
    AS SM_ID
    , VISIT_ID, 'MSG01', CHECK_IN+1, NULL
    FROM VISIT_TBL
    WHERE V_TEM >= 37.5
    ;
    
    ----------------------------------------------------------------------
   SELECT  'SM' || TO_CHAR((SELECT TO_NUMBER(SUBSTR(NVL(MAX(SM_ID), 'SM00000'), 3)) FROM SEND_MSG_TBL) + ROW_NUMBER() OVER(ORDER BY DD), 'FM00000')
                    AS SM_ID ,VISIT_ID,'MSG02',DD,NULL
            FROM (SELECT  
                    VISIT_ID,'MSG02',TO_DATE(TO_CHAR(BCHECK_IN,'YYYYMMDD') + 1) AS DD,NULL ,ROWNUM AS R
                FROM (
                        SELECT A.P_ID AS CON_ID ,A.CHECK_IN AS ACHECK_IN ,A.CHECK_OUT AS ACHECK_OUT ,B.VISIT_ID, B.P_ID AS TLT_PID, B.B_ID,B.CHECK_IN AS BCHECK_IN,B.CHECK_OUT AS BCHECK_OUT
                        FROM (
                            SELECT P_ID,B_ID,CHECK_IN,CHECK_OUT,TO_CHAR(CHECK_IN,'YYYYMMDD') AS D
                            FROM VISIT_TBL
                            WHERE P_ID IN (
                                        SELECT P_ID
                                        FROM CONTAGION_TBL T1, CHECK_UP_TBL T2, SEND_MSG_TBL T3,VISIT_TBL T4
                                        WHERE T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID = T4.VISIT_ID AND T1.CON_ID = :IN_CON_ID
                                       )
                            )A ,VISIT_TBL B
                        WHERE A.B_ID = B.B_ID AND D = TO_CHAR(B.CHECK_IN,'YYYYMMDD')
                    )
                WHERE ((BCHECK_IN <= ACHECK_IN AND BCHECK_OUT >= ACHECK_OUT) OR 
                                                                    ((BCHECK_IN <= ACHECK_IN AND ACHECK_IN < BCHECK_OUT) AND (ACHECK_IN < BCHECK_OUT AND BCHECK_OUT <= ACHECK_OUT)) OR
                                                                    ((ACHECK_IN <= BCHECK_IN AND BCHECK_IN < ACHECK_OUT) AND (BCHECK_IN < ACHECK_OUT AND ACHECK_OUT <= BCHECK_OUT)) OR 
                                                                    (ACHECK_IN <= BCHECK_IN AND BCHECK_OUT <= ACHECK_OUT))  AND CON_ID != TLT_PID )
            
         ;
         
         
         ------------------------------------------------------------------------
         SELECT P_ID
         FROM CONTAGION_TBL T1, CHECK_UP_TBL T2 , SEND_MSG_TBL T3,VISIT_TBL T4
         WHERE T1.CON_ID = :IN_CON_ID AND T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID = T4.VISIT_ID;
         
         -------------------------------------------------Ȯ���� ID�� �ǹ�,��¥ ���ϱ�
         SELECT T_ID, TO_CHAR(CHECK_IN,'YYYYMMDD')
         FROM GET_IN_TBL
         WHERE P_ID = (
                 SELECT P_ID
                 FROM CONTAGION_TBL T1, CHECK_UP_TBL T2 , SEND_MSG_TBL T3,VISIT_TBL T4
                 WHERE T1.CON_ID = :IN_CON_ID AND T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID = T4.VISIT_ID
                      )
         ;
         
         ---------------------------------------------------�����ǹ� , ������¥ �湮��
         SELECT A.P_ID AS CON_ID ,A.CHECK_IN AS ACHECK_IN,A.CHECK_OUT AS ACHECK_OUT,B.GET_IN_ID,B.P_ID AS TLT_ID,B.CHECK_IN AS BCHECK_IN,B_CHECK_OUT AS BCHECK_OUT
         FROM (
                 SELECT P_ID,T_ID, TO_CHAR(CHECK_IN,'YYYYMMDD') AS D1,CHECK_IN,CHECK_OUT
                 FROM GET_IN_TBL
                 WHERE P_ID = (
                         SELECT P_ID
                         FROM CONTAGION_TBL T1, CHECK_UP_TBL T2 , SEND_MSG_TBL T3,VISIT_TBL T4
                         WHERE T1.CON_ID = :IN_CON_ID AND T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID = T4.VISIT_ID
                  )
              ) A,
              GET_IN_TBL B
        WHERE A.T_ID = B.T_ID AND D1 = TO_CHAR(B.CHECK_IN,'YYYYMMDD');
        
        
        -------------------------------------------------------����
        INSERT INTO SEND_MSG_TBL(SM_ID,VISIT_ID,MSG_ID,SM_DATE,GET_IN_ID)
        SELECT 'SM' || TO_CHAR((SELECT TO_NUMBER(SUBSTR(NVL(MAX(SM_ID), 'SM00000'), 3)) FROM SEND_MSG_TBL) + ROW_NUMBER() OVER(ORDER BY SYSDATE), 'FM00000')
                AS SM_ID,NULL,'MSG02',BCHECK_OUT + 1,GET_IN_ID
        FROM(
                 SELECT A.P_ID AS CON_ID1 ,A.CHECK_IN AS ACHECK_IN,A.CHECK_OUT AS ACHECK_OUT,B.GET_IN_ID,B.P_ID AS TLT_ID,B.CHECK_IN AS BCHECK_IN,B.CHECK_OUT AS BCHECK_OUT
                 FROM (
                         SELECT P_ID,T_ID, TO_CHAR(CHECK_IN,'YYYYMMDD') AS D1,CHECK_IN,CHECK_OUT
                         FROM GET_IN_TBL
                         WHERE P_ID = (
                                 SELECT P_ID
                                 FROM CONTAGION_TBL T1, CHECK_UP_TBL T2 , SEND_MSG_TBL T3,VISIT_TBL T4
                                 WHERE T1.CON_ID = :IN_CON_ID AND T1.CHK_ID = T2.CHK_ID AND T2.SM_ID = T3.SM_ID AND T3.VISIT_ID = T4.VISIT_ID
                          )
                      ) A,
                      GET_IN_TBL B
                 WHERE A.T_ID = B.T_ID AND D1 = TO_CHAR(B.CHECK_IN,'YYYYMMDD')
            )
        WHERE ((BCHECK_IN <= ACHECK_IN AND BCHECK_OUT >= ACHECK_OUT) OR 
                                                                    ((BCHECK_IN <= ACHECK_IN AND ACHECK_IN < BCHECK_OUT) AND (ACHECK_IN < BCHECK_OUT AND BCHECK_OUT <= ACHECK_OUT)) OR
                                                                    ((ACHECK_IN <= BCHECK_IN AND BCHECK_IN < ACHECK_OUT) AND (BCHECK_IN < ACHECK_OUT AND ACHECK_OUT <= BCHECK_OUT)) OR 
                                                                    (ACHECK_IN <= BCHECK_IN AND BCHECK_OUT <= ACHECK_OUT))  AND CON_ID1 != TLT_ID 
        ;
        
        --COMMIT;
      